import sys
from PyQt5.QtWidgets import QApplication, QWidget, QFileDialog, QTextEdit, QPushButton, QLabel, QVBoxLayout, \
    QHBoxLayout, QFormLayout, QGroupBox, QSpinBox, QLineEdit, QRadioButton
import pandas as pd
from functools import partial
import od_fi_and_fi_over_od as graph_maker

button_styles = "QPushButton::pressed""{""background-color : green;""}"


def groupbox_style(font_size: int):
    groupbox_title_style = "QGroupBox""{""font-size: %dpx; font-weight: bold;""}" % font_size
    return groupbox_title_style


def remove_widgets_from_layout(layout):
    for i in reversed(range(layout.count())):
        layout.itemAt(i).widget().setParent(QWidget())


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.resize(800, 600)
        self.main_layout = QVBoxLayout()  # main layout of the window goes vertically from top to bottom

        self.data_file = None  # updates when a file is chosen

        # tell the user to click to choose a data file
        self.click_to_begin_groupbox = QGroupBox("Click to begin")
        self.click_to_begin_layout = QFormLayout()
        self.chosen_file = QLabel('No file selected')  # display the file that the user picks
        self.open_file_button = QPushButton('Select Data')
        self.open_file_button.clicked.connect(self.pick_data_file)
        self.click_to_begin_layout.addRow(self.chosen_file)
        self.click_to_begin_layout.addRow(self.open_file_button)
        self.click_to_begin_groupbox.setStyleSheet(groupbox_style(18))
        self.click_to_begin_groupbox.setLayout(self.click_to_begin_layout)
        self.main_layout.addWidget(self.click_to_begin_groupbox)  # add the "open project folder" button

        # ask the user to pick which sheet contains fluorescence data
        self.pick_fi_groupbox = QGroupBox("Which sheet contains fluorescence data?")
        self.pick_fi_groupbox.setStyleSheet(groupbox_style(14))
        self.fi_layout = QFormLayout()
        self.buttonsWidget_fi = QWidget()
        self.buttonsWidgetLayout_fi = QHBoxLayout(self.buttonsWidget_fi)

        self.selected_fi_spreadsheet = QLabel("Selection: None")  # show which sheet the user chose
        self.fi_layout.addRow(self.selected_fi_spreadsheet)

        self.fi_layout.addRow(self.buttonsWidget_fi)
        self.pick_fi_groupbox.setLayout(self.fi_layout)
        self.main_layout.addWidget(self.pick_fi_groupbox)

        # ask the user to pick which sheet contains the optical density data
        self.pick_od_groupbox = QGroupBox("Which sheet contains the optical density data?")
        self.pick_od_groupbox.setStyleSheet(groupbox_style(14))
        self.od_layout = QFormLayout()
        self.buttonsWidget_od = QWidget()
        self.buttonsWidgetLayout_od = QHBoxLayout(self.buttonsWidget_od)

        self.selected_od_spreadsheet = QLabel("Selection: None")  # show which sheet the user chose
        self.od_layout.addRow(self.selected_od_spreadsheet)

        self.od_layout.addRow(self.buttonsWidget_od)
        self.pick_od_groupbox.setLayout(self.od_layout)
        self.main_layout.addWidget(self.pick_od_groupbox)

        # specify the number of replicates
        self.spin_groupbox = QGroupBox("How many replicates?")
        self.spin_groupbox.setStyleSheet(groupbox_style(14))
        self.spin_box_layout = QFormLayout()
        self.spinner = QSpinBox()
        self.spinner.setRange(1, 10)
        self.spinner.setValue(3)  # default to 3 replicates
        self.spin_box_layout.addRow(self.spinner)
        self.spin_groupbox.setLayout(self.spin_box_layout)
        self.main_layout.addWidget(self.spin_groupbox)

        # specify which replicates to plot
        self.replicates_to_plot_groupbox = QGroupBox(
            "Which replicates do you want to see? Enter in the format A1:A3 (bounds are inclusive)")
        self.replicates_to_plot_groupbox.setStyleSheet(groupbox_style(14))
        self.replicates_to_plot_layout = QFormLayout()
        self.replicates_to_plot_textbox = QLineEdit()
        self.replicates_to_plot_layout.addRow(self.replicates_to_plot_textbox)
        self.replicates_to_plot_groupbox.setLayout(self.replicates_to_plot_layout)
        self.main_layout.addWidget(self.replicates_to_plot_groupbox)

        # the button to begin processing
        self.make_graphs_button = QPushButton('Make Graphs')
        self.make_graphs_button.clicked.connect(self.process_data)
        self.main_layout.addWidget(self.make_graphs_button)

        # create the layout
        self.setLayout(self.main_layout)

        self.fi_sheet_label = None  # stores the label of the sheet containing fluorescence data
        self.od_sheet_label = None  # stores the label of the sheet containing optical density data

    def pick_data_file(self):
        """
        Open a window to let the user select an excel file. Displays all sheets in the file and allows users
        to click which sheet contains OD and FI data.
        """

        # reset the selected spreadsheets if a new data file is picked
        self.selected_fi_spreadsheet.setText("Selection: None")
        self.selected_od_spreadsheet.setText("Selection: None")

        self.data_file = QFileDialog.getOpenFileName(
            self, 'Select an Excel file', filter='*.xlsx')[0]
        if self.data_file:
            self.chosen_file.setText(self.data_file)  # display the path to the file the user picked

            remove_widgets_from_layout(self.buttonsWidgetLayout_fi)  # clear any data from a previous file
            remove_widgets_from_layout(self.buttonsWidgetLayout_od)

            # Converts the excel file to a PANDAS dataframe (df)
            df = pd.read_excel(self.data_file, sheet_name=None)
            sheet_names = df.keys()

            # update the buttons so the user can click which sheet they want
            # must be two distinct lists to avoid the problem of only one form showing the buttons
            fi_buttons = [QRadioButton(c) for c in sheet_names]
            od_buttons = [QRadioButton(c) for c in sheet_names]
            for button in fi_buttons:
                # adding background color to button
                # and background color to pressed button
                button.setStyleSheet(button_styles)
                button.clicked.connect(partial(self.pick_fi_sheet, button.text()))
                self.buttonsWidgetLayout_fi.addWidget(button)

            for button in od_buttons:
                # adding background color to button
                # and background color to pressed button
                button.setStyleSheet(button_styles)
                button.clicked.connect(partial(self.pick_od_sheet, button.text()))
                self.buttonsWidgetLayout_od.addWidget(button)

    def pick_fi_sheet(self, label):
        """
        selects the sheet containing fluorescence (FI) data
        """
        self.fi_sheet_label = label
        self.selected_fi_spreadsheet.setText("Selected: %s" % label)

    def pick_od_sheet(self, label):
        """
        selects the sheet containing optical density (OD) data
        """
        self.od_sheet_label = label
        self.selected_od_spreadsheet.setText("Selected: %s" % label)

    def process_data(self):
        if self.data_file is not None and self.fi_sheet_label is not None and self.od_sheet_label is not None and \
                self.replicates_to_plot_textbox.text().strip() is not None:
            fi_data = pd.read_excel(self.data_file, sheet_name=self.fi_sheet_label)
            od_data = pd.read_excel(self.data_file, sheet_name=self.od_sheet_label)
            num_replicates = self.spinner.value()
            replicates_to_plot = self.replicates_to_plot_textbox.text().strip()
            graph_maker.make_od_fi_and_fi_over_od_plots(fi_data, od_data, num_replicates, replicates_to_plot)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    main = MainWindow()
    main.show()
    sys.exit(app.exec_())
